/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Sean
 */
public class Connection {

    public void addTutor(String DBuName, String DBpWord,Student user){
        java.sql.Connection connection = null;
        PreparedStatement stmt;
        String SQL;
        String fName = user.getFName();
        String lName = user.getLName();
        int grade = user.getGrade();
        String uName = user.getUName();
        String pWord = user.getPWord();
        ArrayList<String> Subjects = user.getSubjects();
        String subject = "";
        String available = "";

        for (int i = 0; i < Subjects.size(); i++) {
            if (i != Subjects.size() - 1) {
                subject = subject + Subjects.get(i) + ",";
            } else {
                subject = subject + Subjects.get(i);
            }
        }

        for (int i = 0; i < 5; i++) {
            available = available + i + ":";
            for (int j = 0; j < 5; j++) {
                if (user.getAvailability()[i][j] && j != 4) {
                    available = available + "1" + ",";
                } else if (user.getAvailability()[i][j] && j == 4) {
                    available = available + "1" + ":";
                } else if (!user.getAvailability()[i][j] && j != 4) {
                    available = available + "0" + ",";
                } else if (!user.getAvailability()[i][j] && j == 4) {
                    available = available + "0" + ":";
                }
            }
        }
        try {
            connection = DriverManager.getConnection("jdbc:derby://localhost:1527/Tutoring", DBuName, DBpWord);
            SQL = "INSERT INTO TUTOR " + " (FIRSTNAME,LASTNAME,GRADE,USERNAME,PASSWORD,AVAILABILITY,SUBJECTS)" + " values (?,?,?,?,?,?,?)";
            stmt = connection.prepareStatement(SQL);
            stmt.setString(1, fName);
            stmt.setString(2, lName);
            stmt.setInt(3, grade);
            stmt.setString(4, uName);
            stmt.setString(5, pWord);
            stmt.setString(6, available);
            stmt.setString(7, subject);
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void addTutee(String DBuName, String DBpWord, Student user){
        java.sql.Connection connection = null;
        PreparedStatement stmt;
        String SQL;
        String fName = user.getFName();
        String lName = user.getLName();
        int grade = user.getGrade();
        String uName = user.getUName();
        String pWord = user.getPWord();
        ArrayList<String> Subjects = user.getSubjects();
        String subject = "";
        String available = "";

        for (int i = 0; i < Subjects.size(); i++) {
            if (i != Subjects.size() - 1) {
                subject = subject + Subjects.get(i) + ",";
            } else {
                subject = subject + Subjects.get(i);
            }
        }

        for (int i = 0; i < 5; i++) {
            available = available + i + ":";
            for (int j = 0; j < 5; j++) {
                if (user.getAvailability()[i][j] && j != 4) {
                    available = available + "1" + ",";
                } else if (user.getAvailability()[i][j] && j == 4) {
                    available = available + "1" + ":";
                } else if (!user.getAvailability()[i][j] && j != 4) {
                    available = available + "0" + ",";
                } else if (!user.getAvailability()[i][j] && j == 4) {
                    available = available + "0" + ":";
                }
            }
        }

        try {
            connection = DriverManager.getConnection("jdbc:derby://localhost:1527/Tutoring", DBuName, DBpWord);
            SQL = "INSERT INTO TUTEE " + " (FIRSTNAME,LASTNAME,GRADE,USERNAME,PASSWORD,AVAILABILITY,SUBJECTS)" + " values (?,?,?,?,?,?,?)";
            stmt = connection.prepareStatement(SQL);
            stmt.setString(1, fName);
            stmt.setString(2, lName);
            stmt.setInt(3, grade);
            stmt.setString(4, uName);
            stmt.setString(5, pWord);
            stmt.setString(6, available);
            stmt.setString(7, subject);
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public ArrayList<Student> retrieveAllTutors(String DBuName, String DBpWord) {
        java.sql.Connection connection = null;
        Statement stmt;
        ResultSet rs;
        String SQL;
        String fName = "";
        String lName = "";
        int grade = 0;
        String uName = "";
        String pWord = "";
        ArrayList<String> Subjects = new ArrayList<String>();
        Student user;
        String available = "";
        String subject = "";
        ArrayList<Student> tutors = new ArrayList<Student>();
        boolean[][] availability = new boolean[5][5];
        try {
            connection = DriverManager.getConnection("jdbc:derby://localhost:1527/Tutoring", DBuName, DBpWord);
            stmt = connection.createStatement();
            SQL = "SELECT * FROM Tutor";
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {

                fName = rs.getString(1);
                lName = rs.getString(2);
                grade = rs.getInt(3);
                uName = rs.getString(4);
                pWord = rs.getString(5);
                available = rs.getString(6);
                String[] split = available.split(":");

                for (int i = 1; i < split.length; i = i + 2) {
                    String[] split2 = split[i].split(",");
                    for (int j = 0; j < split2.length; j++) {
                        if (split2[j].equals("1")) {
                            availability[Integer.parseInt(split[i - 1])][j] = true;
                        } else if (split2[j].equals("0")) {
                            availability[Integer.parseInt(split[i - 1])][j] = false;
                        }
                    }

                }
                subject = rs.getString(7);
                String[] newSplit = subject.split(",");
                for (int i = 0; i < newSplit.length; i++) {
                    Subjects.add(i, newSplit[i]);
                }
                user = new Student(fName, lName, grade, uName, pWord, availability, Subjects);
                tutors.add(user);
            }

            stmt.close();
            connection.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return tutors;
    }

    public ArrayList<Student> retrieveAllTutees(String DBuName, String DBpWord) {
        java.sql.Connection connection = null;
        Statement stmt;
        ResultSet rs;
        String SQL;
        String fName = "";
        String lName = "";
        int grade = 0;
        String uName = "";
        String pWord = "";
        ArrayList<String> Subjects = new ArrayList<String>();
        Student user;
        String available = "";
        String subject = "";
        ArrayList<Student> tutees = new ArrayList<Student>();
        boolean[][] availability = new boolean[5][5];
        try {
            connection = DriverManager.getConnection("jdbc:derby://localhost:1527/Tutoring", DBuName, DBpWord);
            stmt = connection.createStatement();
            SQL = "SELECT * FROM Tutee";
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {

                fName = rs.getString(1);
                lName = rs.getString(2);
                grade = rs.getInt(3);
                uName = rs.getString(4);
                pWord = rs.getString(5);
                available = rs.getString(6);
                String[] split = available.split(":");

                for (int i = 1; i < split.length; i = i + 2) {
                    String[] split2 = split[i].split(",");
                    for (int j = 0; j < split2.length; j++) {
                        if (split2[j].equals("1")) {
                            availability[Integer.parseInt(split[i - 1])][j] = true;
                        } else if (split2[j].equals("0")) {
                            availability[Integer.parseInt(split[i - 1])][j] = false;
                        }
                    }

                }
                subject = rs.getString(7);
                String[] newSplit = subject.split(",");
                for (int i = 0; i < newSplit.length; i++) {
                    Subjects.add(i, newSplit[i]);
                }
                user = new Student(fName, lName, grade, uName, pWord, availability, Subjects);
                tutees.add(user);
            }

            stmt.close();
            connection.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return tutees;
    }

}
