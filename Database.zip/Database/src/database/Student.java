/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import java.util.ArrayList;

/**
 *
 * @author Sean
 */
public class Student {

    private String fName;
    private String lName;
    private int grade;
    private String uName;
    private String pWord;
    private boolean[][] availability = new boolean[5][5];
    private ArrayList<String> subjects;

    public Student(String firstName, String lastName, int gr, String userName, String passWord, boolean[][] avail, ArrayList<String> sub) {
        fName = firstName;
        lName = lastName;
        grade = gr;
        uName = userName;
        pWord = passWord;
        availability = avail;
        subjects = sub;
    }
    
    public String getFName(){
    return fName;
    }
    public String getLName(){
    return lName;
    }
    public int getGrade(){
    return grade;
    }
    public String getUName(){
    return uName;
    }
    public String getPWord(){
    return pWord;
    }
    public boolean[][] getAvailability(){
    return availability;
    }
    public ArrayList<String> getSubjects(){
    return subjects;
    }
    public String toString(){
    return fName+" "+lName+" "+grade+" "+uName+" "+pWord;
    }
}
