/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import java.util.ArrayList;

/**
 *
 * @author Sean
 */
public class Database {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Connection c=new Connection();
        String username="APCompSci";
        String password="APCompSci";
        
         boolean[][] avail = new boolean[5][5];

        
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                avail[i][j] = false;
            }
        }
        ArrayList <Student> students=new ArrayList<Student>();
ArrayList<String> Subjects = new ArrayList<String>();
   //     String subject = "";
        Subjects.add("Calculus");
        Subjects.add("Biology");
        Subjects.add("Chemistry");
        Subjects.add("English");
        avail[0][0] = true;
        avail[0][2] = true;
        avail[0][4] = true;
        avail[1][1] = true;
        avail[1][2] = true;
        avail[1][4] = true;
        avail[3][1] = true;
        avail[3][2] = true;
        avail[3][4] = true;
        avail[4][2] = true;
        
        Student jeff=new Student("Jeff","Doran",11,"Jdoran","JDoran",avail,Subjects);
        Student sean = new Student ("Sean","Doran",12,"Stdoran","SwaggyP69",avail,Subjects);
       //c.addTutee(username, password,sean);
        students=c.retrieveAllTutees(username, password);
       for(int i=0;i<students.size();i++){
        
    System.out.println( students.get(i).toString());
      }
        
    }
    
}
